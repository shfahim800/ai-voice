# SH AI Assistant - HTML Web Code Package

This package contains the complete HTML5 and Web source code for **SH AI Assistant**.

## What is inside this ZIP:
1. `standalone/index.html` - Complete self-contained single-file HTML5 web application.
   - Run immediately: Double-click `index.html` in any web browser (Chrome, Edge, Safari, Firefox, Android Chrome). No Node.js or installation needed!
   - 10 full screens: Splash, Home, Chat, Voice Assistant, Plugins, PC Control, Tools, AI Settings, Settings, Connected Devices.
   - Multilingual voice support (Bangla, English, Hindi, Arabic, Spanish, French, German, Japanese, Chinese, etc.).
   - Speech Recognition (STT) and Speech Synthesis (TTS).
   - PC Control simulator over Wi-Fi.

2. `project-source/` - Full React 19 + TypeScript + Vite + Tailwind CSS source code.
   - Run locally:
     ```bash
     cd project-source
     npm install
     npm run dev
     ```
   - Build for production:
     ```bash
     npm run build
     ```

3. Android APK Conversion:
   - You can convert the `standalone/index.html` into a native Android APK using Android Studio WebView or Capacitor:
     ```bash
     npm i -g @capacitor/cli @capacitor/core
     npx cap init "SH AI Assistant" com.sh.assistant
     npx cap add android
     npx cap open android
     ```

Created for SH Fahim.
