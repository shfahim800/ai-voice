export type ScreenType = 
  | 'splash'
  | 'home'
  | 'chat'
  | 'voice'
  | 'voice-settings'
  | 'appearance'
  | 'security-permissions'
  | 'software-update'
  | 'plugins'
  | 'pc-control'
  | 'tools'
  | 'ai-settings'
  | 'settings'
  | 'connected-devices';

export type AppTheme = 
  | 'ios-blur' 
  | 'ios-glass-clear'
  | 'glassmorphism-dark'
  | 'glassmorphism-aurora'
  | 'cyberpunk-neon' 
  | 'cyberpunk-dark' 
  | 'cyberpunk-red'
  | 'cyberpunk-synthwave'
  | 'matrix-green'
  | 'oled-black';

export type AIProvider = 'gemini' | 'openai' | 'ollama' | 'groq';

export interface VoiceLanguageOption {
  code: string;
  shortCode: string;
  name: string;
  nativeName: string;
  flag: string;
  region: string;
  sampleGreeting: string;
  accents?: { code: string; label: string }[];
}

export interface VoiceConfig {
  selectedLanguage: string; // e.g. 'bn-BD', 'en-US', etc.
  autoDetectLanguage: boolean;
  speechRate: number; // 0.75 - 1.5
  speechPitch: number; // 0.8 - 1.3
  voiceGender: 'female' | 'male' | 'neural';
  wakeWordEnabled: boolean;
  wakeWordPhrase: string;
  noiseSuppression: boolean;
  offlineVoiceModel: boolean;
}

export interface ChatMessage {
  id: string;
  sender: 'user' | 'assistant';
  text: string;
  timestamp: string;
  language?: 'bn' | 'en' | string;
  widgetType?: 'weather' | 'product' | 'pc-action' | 'notes';
  widgetData?: any;
}

export interface PluginItem {
  id: string;
  name: string;
  description: string;
  iconName: string;
  enabled: boolean;
  category: 'core' | 'tools' | 'system';
}

export interface PcCommand {
  id: string;
  name: string;
  description: string;
  iconName: string;
  command: string;
  requiresConfirm?: boolean;
}

export interface AssistantSettings {
  userName: string;
  language: 'bn' | 'en' | string;
  provider: AIProvider;
  model: string;
  temperature: number;
  apiKey: string;
  voiceGender: 'female' | 'male' | 'neural';
  wakeWordEnabled: boolean;
  hapticFeedback: boolean;
  pcIpAddress: string;
  pcPort: number;
  pcConnected: boolean;
  phoneConnected: boolean;
  theme: AppTheme;
  voiceConfig?: VoiceConfig;
}
