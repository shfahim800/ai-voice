import React from 'react';
import { 
  Menu, 
  Wifi, 
  Mic, 
  MessageSquare, 
  Monitor, 
  Wrench, 
  Layers, 
  Cpu, 
  ChevronRight,
  Sparkles,
  Download
} from 'lucide-react';
import { ScreenType, AppTheme } from '../../types/assistant';
import { audioService } from '../../services/audioService';
import { themeService } from '../../services/themeService';
import { BatteryWidget } from '../widgets/BatteryWidget';

interface HomeScreenProps {
  userName: string;
  onNavigate: (screen: ScreenType) => void;
  onOpenApkModal: () => void;
  activePluginCount?: number;
}

export const HomeScreen: React.FC<HomeScreenProps> = ({
  userName = 'SH Fahim',
  onNavigate,
  onOpenApkModal,
  activePluginCount = 10,
}) => {
  const [theme, setTheme] = React.useState<AppTheme>(themeService.getTheme());

  React.useEffect(() => {
    const unsub = themeService.subscribe((t) => setTheme(t));
    return () => unsub();
  }, []);

  const handleTileClick = (screen: ScreenType) => {
    audioService.playCyberChime('beep');
    onNavigate(screen);
  };

  const getCardStyle = () => {
    if (theme === 'ios-blur') {
      return 'backdrop-blur-2xl bg-white/[0.08] border border-white/20 shadow-[0_8px_32px_rgba(0,0,0,0.37)] text-white hover:border-white/40';
    }
    if (theme === 'cyberpunk-neon') {
      return 'bg-[#060b1c]/95 border-2 border-[#00f0ff] shadow-[0_0_20px_rgba(0,240,255,0.25)] hover:border-[#ff0055] hover:shadow-[0_0_25px_rgba(255,0,85,0.35)]';
    }
    if (theme === 'matrix-green') {
      return 'bg-[#03150a] border border-emerald-500/50 shadow-[0_0_15px_rgba(16,185,129,0.2)] hover:border-emerald-400';
    }
    if (theme === 'oled-black') {
      return 'bg-[#09090b] border border-neutral-800 shadow-none';
    }
    return 'bg-gradient-to-r from-[#0c1e33] to-[#081526] border border-cyan-500/30 shadow-[0_4px_25px_rgba(8,47,73,0.35)]';
  };

  return (
    <div className="w-full h-full flex flex-col justify-between p-4 overflow-y-auto space-y-4 pb-20 select-none">
      {/* Top Header */}
      <div className="flex items-center justify-between pt-1">
        <button 
          onClick={() => onNavigate('settings')}
          className="w-9 h-9 rounded-xl bg-slate-900/80 border border-slate-800 flex items-center justify-center text-slate-300 hover:text-cyan-400 hover:border-cyan-500/40 transition active:scale-95"
          title="Open Menu"
        >
          <Menu className="w-5 h-5" />
        </button>

        <div className="text-center">
          <h2 className="text-sm font-bold text-white tracking-wide flex items-center justify-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-cyan-400 animate-ping"></span>
            SH AI Assistant
          </h2>
          <p className="text-[10px] text-cyan-400 font-medium">Your Personal AI</p>
        </div>

        <button 
          onClick={() => onNavigate('connected-devices')}
          className="w-9 h-9 rounded-xl bg-slate-900/80 border border-slate-800 flex items-center justify-center text-emerald-400 hover:border-emerald-500/40 transition active:scale-95"
          title="Network & Devices"
        >
          <Wifi className="w-4 h-4" />
        </button>
      </div>

      {/* Greeting Card with Avatar */}
      <div className={`relative overflow-hidden rounded-2xl p-4 transition-all duration-300 flex items-center gap-4 ${getCardStyle()}`}>
        {/* Ambient neon backdrop */}
        <div className="absolute -right-6 -bottom-6 w-28 h-28 bg-cyan-500/10 rounded-full blur-2xl pointer-events-none"></div>

        {/* User Avatar with glowing ring */}
        <div className="relative shrink-0">
          <div className="w-14 h-14 rounded-full bg-gradient-to-tr from-cyan-600 via-sky-400 to-indigo-600 p-[2px] shadow-[0_0_15px_rgba(56,189,248,0.4)]">
            <div className="w-full h-full rounded-full bg-[#030712] flex items-center justify-center overflow-hidden">
              <span className="text-xl font-bold bg-gradient-to-r from-cyan-300 to-sky-400 bg-clip-text text-transparent">
                SH
              </span>
            </div>
          </div>
          <span className="absolute bottom-0 right-0 w-3.5 h-3.5 bg-emerald-500 border-2 border-[#030712] rounded-full"></span>
        </div>

        {/* Welcome text */}
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-1.5">
            <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
            <h3 className="text-sm font-semibold text-white truncate">
              Good Evening, {userName}
            </h3>
          </div>
          <p className="text-xs text-slate-300 mt-0.5">
            How can I help you today?
          </p>
        </div>
      </div>

      {/* Personal AI Battery Status Indicator Widget */}
      <BatteryWidget />

      {/* Primary Action 1: Voice Card */}
      <div
        onClick={() => handleTileClick('voice')}
        className={`group relative cursor-pointer overflow-hidden rounded-2xl p-4 transition-all duration-200 active:scale-[0.98] flex items-center justify-between ${getCardStyle()}`}
      >
        <div className="flex items-center gap-3.5">
          <div className="w-11 h-11 rounded-xl bg-cyan-500/15 border border-cyan-400/40 flex items-center justify-center text-cyan-400 shadow-[0_0_12px_rgba(56,189,248,0.3)] group-hover:scale-110 transition">
            <Mic className="w-5 h-5 stroke-[2.2]" />
          </div>
          <div>
            <h4 className="text-sm font-bold text-white">Voice</h4>
            <p className="text-xs text-cyan-300 font-medium">Tap to speak</p>
          </div>
        </div>

        {/* Animated soundwave bars */}
        <div className="flex items-center gap-1 h-6 px-2">
          <span className="w-1 bg-cyan-400 rounded-full animate-pulse h-3"></span>
          <span className="w-1 bg-cyan-300 rounded-full animate-pulse h-6"></span>
          <span className="w-1 bg-cyan-400 rounded-full animate-pulse h-4"></span>
          <span className="w-1 bg-sky-400 rounded-full animate-pulse h-5"></span>
          <span className="w-1 bg-cyan-400 rounded-full animate-pulse h-2"></span>
        </div>
      </div>

      {/* Primary Action 2: Chat Card */}
      <div
        onClick={() => handleTileClick('chat')}
        className={`group relative cursor-pointer overflow-hidden rounded-2xl p-4 transition-all duration-200 active:scale-[0.98] flex items-center justify-between ${getCardStyle()}`}
      >
        <div className="flex items-center gap-3.5">
          <div className="w-11 h-11 rounded-xl bg-blue-500/15 border border-blue-400/40 flex items-center justify-center text-blue-400 shadow-[0_0_12px_rgba(59,130,246,0.3)] group-hover:scale-110 transition">
            <MessageSquare className="w-5 h-5 stroke-[2.2]" />
          </div>
          <div>
            <h4 className="text-sm font-bold text-white">Chat</h4>
            <p className="text-xs text-slate-300">Type a message...</p>
          </div>
        </div>

        <div className="w-7 h-7 rounded-lg bg-slate-800/80 border border-slate-700/60 flex items-center justify-center text-slate-400 group-hover:text-cyan-400 group-hover:border-cyan-500/50 transition">
          <ChevronRight className="w-4 h-4" />
        </div>
      </div>

      {/* 2x2 Quick Tiles Grid */}
      <div className="grid grid-cols-2 gap-3">
        {/* PC Control */}
        <button
          onClick={() => handleTileClick('pc-control')}
          className="group flex flex-col items-start justify-between p-3.5 rounded-2xl bg-[#091524] border border-cyan-900/60 hover:border-cyan-400/60 transition-all duration-200 active:scale-95 text-left h-24 shadow-sm"
        >
          <div className="w-9 h-9 rounded-xl bg-cyan-500/15 border border-cyan-500/30 flex items-center justify-center text-cyan-400 group-hover:scale-105 transition">
            <Monitor className="w-4 h-4 stroke-[2.2]" />
          </div>
          <div>
            <span className="text-xs font-bold text-white block">PC Control</span>
            <span className="text-[10px] text-slate-400">Windows Commands</span>
          </div>
        </button>

        {/* Tools */}
        <button
          onClick={() => handleTileClick('tools')}
          className="group flex flex-col items-start justify-between p-3.5 rounded-2xl bg-[#091524] border border-cyan-900/60 hover:border-cyan-400/60 transition-all duration-200 active:scale-95 text-left h-24 shadow-sm"
        >
          <div className="w-9 h-9 rounded-xl bg-sky-500/15 border border-sky-500/30 flex items-center justify-center text-sky-400 group-hover:scale-105 transition">
            <Wrench className="w-4 h-4 stroke-[2.2]" />
          </div>
          <div>
            <span className="text-xs font-bold text-white block">Tools</span>
            <span className="text-[10px] text-slate-400">Daily Utilities</span>
          </div>
        </button>

        {/* Plugins */}
        <button
          onClick={() => handleTileClick('plugins')}
          className="group flex flex-col items-start justify-between p-3.5 rounded-2xl bg-[#091524] border border-cyan-900/60 hover:border-cyan-400/60 transition-all duration-200 active:scale-95 text-left h-24 shadow-sm relative"
        >
          <div className="flex items-center justify-between w-full">
            <div className="w-9 h-9 rounded-xl bg-blue-500/15 border border-blue-500/30 flex items-center justify-center text-blue-400 group-hover:scale-105 transition">
              <Layers className="w-4 h-4 stroke-[2.2]" />
            </div>
            <span className="text-[10px] font-bold text-cyan-300 bg-cyan-950/80 border border-cyan-500/40 px-2 py-0.5 rounded-full">
              {activePluginCount}
            </span>
          </div>
          <div>
            <span className="text-xs font-bold text-white block">Plugins</span>
            <span className="text-[10px] text-slate-400">10+ Smart Tools</span>
          </div>
        </button>

        {/* Automation */}
        <button
          onClick={() => handleTileClick('tools')}
          className="group flex flex-col items-start justify-between p-3.5 rounded-2xl bg-[#091524] border border-cyan-900/60 hover:border-cyan-400/60 transition-all duration-200 active:scale-95 text-left h-24 shadow-sm"
        >
          <div className="w-9 h-9 rounded-xl bg-indigo-500/15 border border-indigo-500/30 flex items-center justify-center text-indigo-400 group-hover:scale-105 transition">
            <Cpu className="w-4 h-4 stroke-[2.2]" />
          </div>
          <div>
            <span className="text-xs font-bold text-white block">Automation</span>
            <span className="text-[10px] text-slate-400">Tasks & Workflows</span>
          </div>
        </button>
      </div>

      {/* AI Agent Status Footer Card */}
      <div 
        onClick={() => handleTileClick('ai-settings')}
        className="cursor-pointer rounded-2xl bg-gradient-to-r from-[#05111f] to-[#081a30] border border-cyan-500/30 p-3 flex items-center justify-between hover:border-cyan-400/60 transition"
      >
        <div className="flex items-center gap-2.5">
          <span className="relative flex h-2.5 w-2.5">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-emerald-500"></span>
          </span>
          <div>
            <h5 className="text-xs font-bold text-white">AI Agent Online</h5>
            <p className="text-[10px] text-cyan-400 font-mono">Ollama + OpenAI + Gemini</p>
          </div>
        </div>

        {/* Equalizer animation */}
        <div className="flex items-end gap-1 h-5 px-1">
          <span className="w-1 bg-cyan-400 rounded-full animate-bounce h-2"></span>
          <span className="w-1 bg-cyan-400 rounded-full animate-bounce h-4" style={{ animationDelay: '0.15s' }}></span>
          <span className="w-1 bg-cyan-400 rounded-full animate-bounce h-5" style={{ animationDelay: '0.3s' }}></span>
          <span className="w-1 bg-cyan-400 rounded-full animate-bounce h-3" style={{ animationDelay: '0.45s' }}></span>
        </div>
      </div>
    </div>
  );
};
