import React, { useState } from 'react';
import { 
  FileText, 
  Calculator, 
  Folder, 
  Globe, 
  Camera, 
  Power, 
  Wifi, 
  ArrowLeft,
  Download,
  CheckCircle,
  AlertTriangle,
  ExternalLink
} from 'lucide-react';
import { audioService } from '../../services/audioService';
import { downloadWindowsScript } from '../../services/apkGenerator';

interface PcControlScreenProps {
  onBack: () => void;
  pcIp?: string;
}

export const PcControlScreen: React.FC<PcControlScreenProps> = ({ 
  onBack, 
  pcIp = '192.168.1.10' 
}) => {
  const [feedback, setFeedback] = useState<string | null>(null);
  const [confirmShutdown, setConfirmShutdown] = useState(false);
  const [screenshotFlash, setScreenshotFlash] = useState(false);

  const triggerCommand = async (action: string, label: string) => {
    audioService.playCyberChime('activate');

    if (action === 'take_screenshot') {
      setScreenshotFlash(true);
      setTimeout(() => setScreenshotFlash(false), 300);
    }

    // Try communicating with local companion agent if running on PC
    try {
      fetch(`http://${pcIp}:5890`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action })
      }).catch(() => {});
    } catch (e) {}

    setFeedback(`Executed: ${label}`);
    setTimeout(() => setFeedback(null), 3000);
  };

  const commands = [
    {
      id: 'notepad',
      name: 'Open Notepad',
      desc: 'Quick text editor',
      icon: FileText,
      color: 'text-cyan-400',
      action: 'open_notepad'
    },
    {
      id: 'calc',
      name: 'Open Calculator',
      desc: 'Simple & fast',
      icon: Calculator,
      color: 'text-blue-400',
      action: 'open_calc'
    },
    {
      id: 'files',
      name: 'File Manager',
      desc: 'Browse files',
      icon: Folder,
      color: 'text-sky-400',
      action: 'open_explorer'
    },
    {
      id: 'browser',
      name: 'Open Browser',
      desc: 'Chrome/Edge/Firefox',
      icon: Globe,
      color: 'text-cyan-300',
      action: 'open_browser'
    },
    {
      id: 'screenshot',
      name: 'Take Screenshot',
      desc: 'Capture screen',
      icon: Camera,
      color: 'text-indigo-400',
      action: 'take_screenshot'
    },
    {
      id: 'power',
      name: 'Shutdown / Restart',
      desc: 'System control',
      icon: Power,
      color: 'text-rose-400',
      action: 'power_dialog'
    }
  ];

  return (
    <div className="relative w-full h-full flex flex-col justify-between bg-[#030712] select-none p-4 pb-20 overflow-y-auto space-y-4">
      {/* Screen flash for screenshot */}
      {screenshotFlash && (
        <div className="absolute inset-0 bg-white/40 z-50 pointer-events-none animate-pulse"></div>
      )}

      {/* Header matching Screen 6 */}
      <div className="flex items-center justify-between pt-1">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-lg bg-cyan-500/15 border border-cyan-500/30 flex items-center justify-center text-cyan-400">
            <Globe className="w-4 h-4" />
          </div>
          <div>
            <h2 className="text-sm font-bold text-white tracking-wide">PC Control</h2>
            <p className="text-[10px] text-slate-400">Control your computer</p>
          </div>
        </div>

        <button
          onClick={() => {
            audioService.playCyberChime('beep');
            alert("PC Status: Connected to Windows 11 Workstation via 192.168.1.10:5890");
          }}
          className="w-8 h-8 rounded-lg bg-slate-900 border border-slate-800 flex items-center justify-center text-slate-400 hover:text-cyan-400 transition"
        >
          <div className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></div>
        </button>
      </div>

      {/* Execution Feedback Notification */}
      {feedback && (
        <div className="p-2.5 rounded-xl bg-cyan-950/90 border border-cyan-400 text-cyan-200 text-xs flex items-center gap-2 animate-fade-in shadow-[0_0_15px_rgba(56,189,248,0.3)]">
          <CheckCircle className="w-4 h-4 text-cyan-400 shrink-0" />
          <span>{feedback}</span>
        </div>
      )}

      {/* 6 Grid Command Tiles */}
      <div className="grid grid-cols-2 gap-3">
        {commands.map((cmd) => {
          const Icon = cmd.icon;
          return (
            <button
              key={cmd.id}
              onClick={() => {
                if (cmd.id === 'power') {
                  setConfirmShutdown(true);
                } else {
                  triggerCommand(cmd.action, cmd.name);
                }
              }}
              className="flex flex-col items-center justify-center p-4 rounded-2xl bg-[#091524] border border-cyan-900/60 hover:border-cyan-400/80 transition-all duration-200 active:scale-95 text-center group h-32 shadow-sm"
            >
              <div className={`w-12 h-12 rounded-2xl bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center ${cmd.color} group-hover:scale-110 transition shadow-inner mb-2`}>
                <Icon className="w-6 h-6 stroke-[2]" />
              </div>
              <h4 className="text-xs font-bold text-white group-hover:text-cyan-300 transition">
                {cmd.name}
              </h4>
              <p className="text-[10px] text-slate-400 mt-0.5">
                {cmd.desc}
              </p>
            </button>
          );
        })}
      </div>

      {/* Shutdown confirmation dialog */}
      {confirmShutdown && (
        <div className="p-4 rounded-2xl bg-[#0f172a] border border-rose-500/50 space-y-3">
          <div className="flex items-center gap-2 text-rose-400 font-bold text-xs">
            <AlertTriangle className="w-4 h-4" />
            <span>Power Options for PC ({pcIp})</span>
          </div>
          <p className="text-[11px] text-slate-300">
            Choose an action to send to Windows PC via Wi-Fi:
          </p>
          <div className="flex gap-2">
            <button
              onClick={() => {
                triggerCommand('lock_pc', 'PC Locked');
                setConfirmShutdown(false);
              }}
              className="flex-1 py-2 text-[11px] bg-slate-800 text-slate-200 rounded-lg hover:bg-slate-700"
            >
              Lock PC
            </button>
            <button
              onClick={() => {
                triggerCommand('restart', 'PC Restart Command');
                setConfirmShutdown(false);
              }}
              className="flex-1 py-2 text-[11px] bg-amber-600/30 text-amber-300 border border-amber-500/50 rounded-lg"
            >
              Restart
            </button>
            <button
              onClick={() => {
                triggerCommand('shutdown', 'PC Shutdown Command');
                setConfirmShutdown(false);
              }}
              className="flex-1 py-2 text-[11px] bg-rose-600 text-white rounded-lg hover:bg-rose-700"
            >
              Shutdown
            </button>
          </div>
          <button 
            onClick={() => setConfirmShutdown(false)}
            className="w-full py-1 text-[10px] text-slate-400 hover:text-white"
          >
            Cancel
          </button>
        </div>
      )}

      {/* Bottom PC Connected Card */}
      <div className="rounded-2xl bg-gradient-to-r from-[#05111f] to-[#081a30] border border-cyan-500/40 p-3.5 flex items-center justify-between shadow-sm">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-emerald-500/15 border border-emerald-500/40 flex items-center justify-center text-emerald-400">
            <Wifi className="w-4 h-4" />
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
              <h5 className="text-xs font-bold text-white">PC Connected</h5>
            </div>
            <p className="text-[10px] text-slate-400 font-mono">
              Same Wi-Fi Network {pcIp}
            </p>
          </div>
        </div>

        {/* Live Network Equalizer */}
        <div className="flex items-end gap-1 h-5 px-1">
          <span className="w-1 bg-emerald-400 rounded-full animate-bounce h-2"></span>
          <span className="w-1 bg-emerald-400 rounded-full animate-bounce h-4" style={{ animationDelay: '0.15s' }}></span>
          <span className="w-1 bg-emerald-400 rounded-full animate-bounce h-5" style={{ animationDelay: '0.3s' }}></span>
          <span className="w-1 bg-emerald-400 rounded-full animate-bounce h-3" style={{ animationDelay: '0.45s' }}></span>
        </div>
      </div>
    </div>
  );
};
