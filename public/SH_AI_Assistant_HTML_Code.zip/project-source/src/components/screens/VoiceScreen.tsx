import React, { useState, useEffect } from 'react';
import { ArrowLeft, Mic, Square, Play, Volume2 } from 'lucide-react';
import { motion } from 'motion/react';
import { audioService } from '../../services/audioService';
import { askAssistantAI } from '../../services/geminiService';

interface VoiceScreenProps {
  onBack: () => void;
  onNavigate?: (screen: any) => void;
  apiKey?: string;
}

export const VoiceScreen: React.FC<VoiceScreenProps> = ({ onBack, onNavigate, apiKey }) => {
  const [isListening, setIsListening] = useState(true);
  const [transcript, setTranscript] = useState('');
  const [reply, setReply] = useState('শুনছি... বলুন...');
  const [isSpeaking, setIsSpeaking] = useState(false);
  const voiceConfig = audioService.getConfig();

  useEffect(() => {
    startListeningSession();
    return () => {
      audioService.stopListening();
      audioService.stopSpeaking();
    };
  }, []);

  const startListeningSession = () => {
    setIsListening(true);
    setTranscript('');
    const isBangla = voiceConfig.selectedLanguage.startsWith('bn');
    setReply(isBangla ? 'শুনছি... বলুন... (Listening...)' : 'Listening... Speak now...');
    
    const started = audioService.startListening(
      async (text) => {
        setTranscript(text);
        if (text.length > 3) {
          // Process spoken query
          audioService.stopListening();
          setIsListening(false);
          setReply(isBangla ? 'প্রক্রিয়াকরণ হচ্ছে... (Processing...)' : 'Processing your voice query...');
          
          try {
            const res = await askAssistantAI(text, apiKey);
            setReply(res.text);
            setIsSpeaking(true);
            audioService.speak(res.text);
            setTimeout(() => setIsSpeaking(false), 5000);
          } catch (e) {
            setReply(isBangla ? 'দুঃখিত, পুনরায় বলুন।' : 'Sorry, could not process. Please speak again.');
          }
        }
      },
      (error) => {
        console.warn('Speech error:', error);
        setReply(isBangla ? 'মাইক্রোফোন সক্রিয় করুন বা টেস্ট কমান্ড চাপুন।' : 'Microphone ready. Tap a quick command.');
        setIsListening(false);
      },
      voiceConfig.selectedLanguage
    );

    if (!started) {
      setReply('শুনছি... নিচের যেকোনো কমান্ডে ট্যাপ করুন');
    }
  };

  const stopSession = () => {
    audioService.stopListening();
    audioService.stopSpeaking();
    setIsListening(false);
    setIsSpeaking(false);
    audioService.playCyberChime('alert');
  };

  const handleQuickCommand = async (cmd: string) => {
    setTranscript(cmd);
    setIsListening(false);
    setReply('প্রক্রিয়াকরণ হচ্ছে...');
    const res = await askAssistantAI(cmd, apiKey);
    setReply(res.text);
    setIsSpeaking(true);
    audioService.speak(res.text);
    setTimeout(() => setIsSpeaking(false), 5000);
  };

  return (
    <div className="relative w-full h-full min-h-[660px] bg-[#030712] flex flex-col justify-between p-6 select-none overflow-hidden">
      {/* Background radial glow */}
      <div className="absolute top-1/3 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[340px] h-[340px] bg-cyan-600/15 rounded-full blur-[90px] pointer-events-none"></div>

      {/* Header */}
      <div className="flex items-center justify-between z-10">
        <button 
          onClick={onBack}
          className="w-9 h-9 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-center text-slate-300 hover:text-cyan-400 transition cursor-pointer"
        >
          <ArrowLeft className="w-5 h-5" />
        </button>

        <div className="text-center">
          <h2 className="text-base font-bold text-white tracking-wide">Voice Assistant</h2>
          <div className="flex items-center justify-center gap-1.5 mt-0.5">
            <span className={`w-2 h-2 rounded-full ${isListening ? 'bg-cyan-400 animate-ping' : 'bg-slate-600'}`}></span>
            <span className="text-xs text-cyan-400 font-medium">
              {isListening ? 'Listening...' : isSpeaking ? 'Speaking...' : 'Standby'}
            </span>
            <button
              onClick={() => onNavigate && onNavigate('voice-settings')}
              className="ml-1 text-[10px] bg-cyan-950/90 border border-cyan-500/40 text-cyan-300 px-2 py-0.5 rounded-full font-mono hover:bg-cyan-900 transition cursor-pointer"
              title="Change Voice Language"
            >
              {voiceConfig.selectedLanguage}
            </button>
          </div>
        </div>

        <button
          onClick={() => onNavigate && onNavigate('voice-settings')}
          className="w-9 h-9 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-center text-slate-300 hover:text-cyan-400 hover:border-cyan-500/40 transition cursor-pointer"
          title="Voice & Multi-Language Settings"
        >
          <Volume2 className="w-4 h-4" />
        </button>
      </div>

      {/* Center Holographic Voice Orb */}
      <div className="relative flex flex-col items-center justify-center my-auto z-10 py-4">
        <div className="relative w-64 h-64 flex items-center justify-center">
          {/* Animated concentric pulse waves */}
          <motion.div 
            animate={{ 
              scale: isListening || isSpeaking ? [1, 1.25, 1] : 1,
              opacity: isListening || isSpeaking ? [0.3, 0.7, 0.3] : 0.2
            }}
            transition={{ repeat: Infinity, duration: 2.2, ease: "easeInOut" }}
            className="absolute inset-0 rounded-full border border-cyan-400/40 glow-cyan"
          />

          <motion.div 
            animate={{ 
              scale: isListening || isSpeaking ? [1.1, 1.35, 1.1] : 1,
              opacity: isListening || isSpeaking ? [0.2, 0.5, 0.2] : 0.1
            }}
            transition={{ repeat: Infinity, duration: 2.8, ease: "easeInOut" }}
            className="absolute -inset-4 rounded-full border border-blue-500/30"
          />

          {/* Rotating dashed ring */}
          <div className="absolute inset-2 rounded-full border border-dashed border-cyan-500/50 animate-tech-spin"></div>

          {/* High-tech Inner Glowing Sphere */}
          <div className="w-36 h-36 rounded-full bg-gradient-to-tr from-[#082f49] via-[#0284c7] to-[#2563eb] border-2 border-cyan-300 shadow-[0_0_40px_rgba(56,189,248,0.6)] flex items-center justify-center cursor-pointer active:scale-95 transition"
            onClick={isListening ? stopSession : startListeningSession}
          >
            <Mic className={`w-14 h-14 ${isListening ? 'text-white animate-pulse' : 'text-cyan-100'} stroke-[2.2] drop-shadow-[0_0_12px_rgba(255,255,255,0.8)]`} />
          </div>
        </div>

        {/* Dynamic Prompt / Subtitle */}
        <div className="text-center mt-6 px-4 max-w-sm">
          <p className="text-lg font-bold text-white tracking-wide font-sans">
            {reply}
          </p>
          {transcript && (
            <p className="text-xs text-cyan-300/90 mt-1 italic">
              "{transcript}"
            </p>
          )}
        </div>

        {/* Real-time Dynamic Soundwave Frequency Visualizer */}
        <div className="flex items-center justify-center gap-1 h-12 mt-6 w-full max-w-xs px-4">
          {[4, 8, 16, 28, 42, 30, 18, 35, 48, 32, 20, 12, 38, 24, 10, 5].map((val, i) => (
            <motion.span
              key={i}
              animate={{ 
                height: isListening || isSpeaking ? [8, val, 6] : 6,
                backgroundColor: isListening ? '#38bdf8' : isSpeaking ? '#60a5fa' : '#334155'
              }}
              transition={{ 
                repeat: Infinity, 
                duration: 0.6 + (i % 5) * 0.15,
                ease: "easeInOut" 
              }}
              className="w-1.5 rounded-full shadow-[0_0_6px_rgba(56,189,248,0.5)]"
              style={{ minHeight: '6px' }}
            />
          ))}
        </div>
      </div>

      {/* Spoken preset quick chips */}
      <div className="flex items-center justify-center gap-2 overflow-x-auto py-2 z-10 text-[11px]">
        <button 
          onClick={() => handleQuickCommand('আজকের তাপমাত্রা কত?')}
          className="bg-slate-900 border border-cyan-900/60 hover:border-cyan-400 text-slate-300 px-3 py-1.5 rounded-full transition"
        >
          🌤️ আজকের তাপমাত্রা
        </button>
        <button 
          onClick={() => handleQuickCommand('Open Calculator on PC')}
          className="bg-slate-900 border border-cyan-900/60 hover:border-cyan-400 text-slate-300 px-3 py-1.5 rounded-full transition"
        >
          💻 ওপেন ক্যালকুলেটর
        </button>
      </div>

      {/* Stop / Speak Action Button */}
      <div className="flex items-center justify-center pb-4 z-10">
        {isListening ? (
          <button
            onClick={stopSession}
            className="flex items-center gap-2.5 px-6 py-3 rounded-full bg-gradient-to-r from-rose-900/80 to-rose-700/80 border border-rose-500/80 text-white font-semibold text-xs shadow-[0_0_20px_rgba(244,63,94,0.4)] hover:brightness-110 active:scale-95 transition"
          >
            <Square className="w-4 h-4 fill-white" />
            <span>Tap to stop</span>
          </button>
        ) : (
          <button
            onClick={startListeningSession}
            className="flex items-center gap-2.5 px-6 py-3 rounded-full bg-gradient-to-r from-cyan-600 to-blue-600 border border-cyan-400 text-white font-semibold text-xs shadow-[0_0_20px_rgba(56,189,248,0.4)] hover:brightness-110 active:scale-95 transition"
          >
            <Play className="w-4 h-4 fill-white" />
            <span>Tap to speak</span>
          </button>
        )}
      </div>
    </div>
  );
};
