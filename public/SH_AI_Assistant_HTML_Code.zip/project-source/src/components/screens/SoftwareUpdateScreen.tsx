import React, { useState, useEffect } from 'react';
import { 
  ArrowLeft, 
  DownloadCloud, 
  RefreshCw, 
  CheckCircle2, 
  Sparkles, 
  Smartphone, 
  Layers, 
  ShieldCheck, 
  GitBranch, 
  HardDrive, 
  Clock, 
  ChevronRight, 
  FileCheck, 
  Zap, 
  Radio, 
  ExternalLink,
  Sliders,
  Check
} from 'lucide-react';
import { audioService } from '../../services/audioService';
import confetti from 'canvas-confetti';

interface SoftwareUpdateScreenProps {
  onBack: () => void;
  onOpenApkModal: () => void;
}

export const SoftwareUpdateScreen: React.FC<SoftwareUpdateScreenProps> = ({
  onBack,
  onOpenApkModal
}) => {
  const currentVersion = 'v2.4.0 (Build 42)';
  const latestVersion = 'v2.5.0-PRO (Cyber & Glass Edition)';

  const [isChecking, setIsChecking] = useState<boolean>(false);
  const [updateStatus, setUpdateStatus] = useState<'idle' | 'available' | 'downloading' | 'ready' | 'up-to-date'>('available');
  const [downloadProgress, setDownloadProgress] = useState<number>(0);
  const [updateChannel, setUpdateChannel] = useState<'stable' | 'beta' | 'canary'>('stable');
  const [autoCheckOnLaunch, setAutoCheckOnLaunch] = useState<boolean>(true);
  const [wifiOnly, setWifiOnly] = useState<boolean>(true);
  const [notifyOnNewBuild, setNotifyOnNewBuild] = useState<boolean>(true);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const handleCheckForUpdates = () => {
    audioService.playCyberChime('activate');
    setIsChecking(true);
    setToastMessage(null);

    setTimeout(() => {
      setIsChecking(false);
      setUpdateStatus('available');
      audioService.playCyberChime('success');
      setToastMessage('নতুন আপডেট পাওয়া গেছে: v2.5.0-PRO (New Update Available)');
      setTimeout(() => setToastMessage(null), 3500);
    }, 1200);
  };

  const handleStartDownload = () => {
    audioService.playCyberChime('beep');
    setUpdateStatus('downloading');
    setDownloadProgress(0);

    const interval = setInterval(() => {
      setDownloadProgress(prev => {
        if (prev >= 100) {
          clearInterval(interval);
          setUpdateStatus('ready');
          audioService.playCyberChime('success');
          try {
            confetti({
              particleCount: 35,
              spread: 60,
              origin: { y: 0.6 },
              colors: ['#00f0ff', '#10b981', '#38bdf8']
            });
          } catch {}
          return 100;
        }
        return prev + 15;
      });
    }, 280);
  };

  const handleApplyUpdate = () => {
    audioService.playCyberChime('activate');
    setToastMessage('আপডেট প্যাকেজ কার্যকর হচ্ছে... অ্যাপ রিস্টার্ট করা হচ্ছে...');
    
    // Trigger download of existing built APK as physical package
    const link = document.createElement('a');
    link.href = '/app-debug.apk';
    link.download = 'SH_AI_Assistant_v2.5.0.apk';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);

    setTimeout(() => {
      setUpdateStatus('up-to-date');
      setToastMessage('সফলভাবে আপডেট ইনস্টল সম্পন্ন হয়েছে! (App successfully updated)');
    }, 2000);
  };

  return (
    <div className="w-full h-full flex flex-col justify-between bg-[#030712] select-none p-4 pb-20 overflow-y-auto space-y-4">
      {/* Top Header */}
      <div className="flex items-center justify-between pt-1">
        <div className="flex items-center gap-2.5">
          <button 
            onClick={onBack}
            className="w-8 h-8 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-center text-slate-300 hover:text-cyan-400 transition active:scale-95"
            title="Go Back"
          >
            <ArrowLeft className="w-4 h-4" />
          </button>
          <div>
            <h2 className="text-sm font-bold text-white tracking-wide flex items-center gap-1.5">
              <DownloadCloud className="w-4 h-4 text-cyan-400" />
              Software & App Update
            </h2>
            <p className="text-[10px] text-cyan-400 font-medium">সফটওয়্যার ও নতুন সংস্করণ আপডেট</p>
          </div>
        </div>

        <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-cyan-950/80 border border-cyan-500/40 text-cyan-300">
          OTA Active
        </span>
      </div>

      {/* Toast feedback */}
      {toastMessage && (
        <div className="p-2.5 rounded-xl bg-cyan-950/90 border border-cyan-400/80 text-cyan-200 text-xs flex items-center gap-2 shadow-[0_0_15px_rgba(56,189,248,0.3)] animate-fade-in">
          <CheckCircle2 className="w-4 h-4 text-cyan-400 shrink-0" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Hero Update Status Card */}
      <div className="relative overflow-hidden rounded-2xl p-4 bg-gradient-to-br from-[#071a2e] via-[#0b2442] to-[#041221] border border-cyan-500/40 shadow-[0_8px_32px_rgba(56,189,248,0.2)]">
        <div className="flex items-start justify-between">
          <div className="space-y-1">
            <span className="text-[10px] uppercase font-mono font-bold text-cyan-400 tracking-wider flex items-center gap-1.5">
              <Zap className="w-3.5 h-3.5 text-cyan-400" />
              SH Assistant OTA Client
            </span>
            <h3 className="text-base font-extrabold text-white">
              {updateStatus === 'up-to-date' 
                ? 'আপনার অ্যাপ আপ-টু-ডেট আছে' 
                : updateStatus === 'ready' 
                ? 'আপডেট ইনস্টলের জন্য প্রস্তুত!' 
                : 'নতুন সংস্করণ উপলব্ধ (Update Found)'}
            </h3>
            <p className="text-xs text-slate-300 leading-relaxed">
              ইনস্টল করা সংস্করণ: <span className="font-mono text-cyan-300 font-bold">{currentVersion}</span>
            </p>
          </div>

          <div className="w-12 h-12 rounded-2xl bg-cyan-950/80 border border-cyan-500/50 flex items-center justify-center text-cyan-400 shadow-inner shrink-0">
            {isChecking ? (
              <RefreshCw className="w-6 h-6 animate-spin text-cyan-300" />
            ) : updateStatus === 'ready' ? (
              <FileCheck className="w-6 h-6 text-emerald-400" />
            ) : (
              <DownloadCloud className="w-6 h-6 stroke-[2.2]" />
            )}
          </div>
        </div>

        {/* Action button / Progress */}
        <div className="mt-4 pt-3 border-t border-cyan-950/80">
          {isChecking ? (
            <div className="flex items-center justify-center gap-2 text-xs text-cyan-300 font-mono py-1">
              <RefreshCw className="w-4 h-4 animate-spin" />
              <span>সার্ভারে নতুন ভার্সন চেক করা হচ্ছে...</span>
            </div>
          ) : updateStatus === 'downloading' ? (
            <div className="space-y-2">
              <div className="flex items-center justify-between text-xs text-cyan-300 font-mono">
                <span>প্যাকেজ ডাউনলোড হচ্ছে...</span>
                <span>{downloadProgress}%</span>
              </div>
              <div className="w-full h-2 rounded-full bg-slate-900 overflow-hidden border border-cyan-500/40">
                <div 
                  className="h-full bg-gradient-to-r from-cyan-500 to-emerald-400 transition-all duration-200"
                  style={{ width: `${downloadProgress}%` }}
                ></div>
              </div>
            </div>
          ) : updateStatus === 'ready' ? (
            <div className="flex items-center gap-2">
              <button
                onClick={handleApplyUpdate}
                className="flex-1 py-2.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-black font-extrabold text-xs flex items-center justify-center gap-2 shadow-[0_0_15px_rgba(16,185,129,0.5)] transition active:scale-95"
              >
                <Check className="w-4 h-4 stroke-[3]" />
                এখনই ইনস্টল করুন (Install & Apply)
              </button>
            </div>
          ) : updateStatus === 'up-to-date' ? (
            <div className="flex items-center justify-between">
              <span className="text-xs text-emerald-300 flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                সর্বশেষ সংস্করণ সক্রিয়
              </span>
              <button
                onClick={handleCheckForUpdates}
                className="px-3 py-1.5 rounded-xl bg-slate-900 border border-slate-700 text-slate-300 hover:text-white text-xs font-semibold flex items-center gap-1.5 transition active:scale-95"
              >
                <RefreshCw className="w-3.5 h-3.5" />
                আবার চেক করুন
              </button>
            </div>
          ) : (
            <div className="flex items-center gap-2">
              <button
                onClick={handleStartDownload}
                className="flex-1 py-2.5 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-black font-extrabold text-xs flex items-center justify-center gap-2 shadow-[0_0_15px_rgba(56,189,248,0.5)] transition active:scale-95"
              >
                <DownloadCloud className="w-4 h-4 stroke-[2.4]" />
                আপডেট ডাউনলোড করুন (24.8 MB)
              </button>
              <button
                onClick={handleCheckForUpdates}
                className="px-3 py-2.5 rounded-xl bg-slate-900 border border-cyan-950 text-cyan-300 text-xs font-semibold hover:bg-slate-800 transition active:scale-95"
                title="Force refresh"
              >
                <RefreshCw className="w-4 h-4" />
              </button>
            </div>
          )}
        </div>
      </div>

      {/* What's New / Release Notes */}
      <div className="p-3.5 rounded-2xl bg-[#081525] border border-cyan-950 space-y-2.5">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-1.5">
            <Sparkles className="w-4 h-4 text-cyan-400" />
            <h4 className="text-xs font-bold text-white">নতুন কী আসছে (What's New in v2.5.0)</h4>
          </div>
          <span className="text-[10px] font-mono text-cyan-400">Release Notes</span>
        </div>

        <div className="space-y-2 text-xs text-slate-300">
          <div className="p-2 rounded-xl bg-[#050e1a] border border-cyan-950 flex items-start gap-2">
            <span className="text-cyan-400 font-bold text-sm leading-none mt-0.5">•</span>
            <div>
              <strong className="text-white">নতুন সাইবারপাঙ্ক ও iOS লিকুইড গ্লাস থিম:</strong>
              <p className="text-[11px] text-slate-400 mt-0.5">
                Arasaka Syndicate Crimson, Synthwave 84, এবং Apple iOS 18 লিকুইড ক্রিস্টাল গ্লাস ও ফ্রস্টেড গ্লাস ব্লার মোড যুক্ত হয়েছে।
              </p>
            </div>
          </div>

          <div className="p-2 rounded-xl bg-[#050e1a] border border-cyan-950 flex items-start gap-2">
            <span className="text-emerald-400 font-bold text-sm leading-none mt-0.5">•</span>
            <div>
              <strong className="text-white">অ্যাডভান্স পারমিশন ও সিকিউরিটি শিল্ড:</strong>
              <p className="text-[11px] text-slate-400 mt-0.5">
                মিলিটারি-গ্রেড অন-ডিভাইস এনক্রিপশন, লাইভ সিকিউরিটি অডিট রেডার, ৪-ডিজিট মাস্টার পিন ও গ্র্যানুলার পারমিশন কন্ট্রোল।
              </p>
            </div>
          </div>

          <div className="p-2 rounded-xl bg-[#050e1a] border border-cyan-950 flex items-start gap-2">
            <span className="text-amber-400 font-bold text-sm leading-none mt-0.5">•</span>
            <div>
              <strong className="text-white">ভার্চুয়াল এআই ব্যাটারি ইন্ডিকেটর উইজেট:</strong>
              <p className="text-[11px] text-slate-400 mt-0.5">
                ড্যাশবোর্ডে রিয়েল ও ভার্চুয়াল এআই পাওয়ার মনিটর, Eco / Turbo মোড এবং সিস্টেম-ওয়াইড সিঙ্ক।
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Release Channel Selector */}
      <div className="p-3.5 rounded-2xl bg-[#081525] border border-cyan-950 space-y-2">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-1.5">
            <GitBranch className="w-4 h-4 text-purple-400" />
            <h4 className="text-xs font-bold text-white">আপডেট চ্যানেল (Update Channel)</h4>
          </div>
          <span className="text-[10px] font-mono text-purple-300 uppercase">
            {updateChannel}
          </span>
        </div>

        <div className="grid grid-cols-3 gap-1.5 text-center text-xs">
          <button
            onClick={() => { audioService.playCyberChime('beep'); setUpdateChannel('stable'); }}
            className={`py-1.5 px-2 rounded-xl text-[11px] font-medium transition ${
              updateChannel === 'stable'
                ? 'bg-purple-600 text-white font-bold shadow-[0_0_10px_rgba(168,85,247,0.5)]'
                : 'bg-slate-900 text-slate-400 hover:text-white border border-slate-800'
            }`}
          >
            Stable (অফিসিয়াল)
          </button>
          <button
            onClick={() => { audioService.playCyberChime('beep'); setUpdateChannel('beta'); }}
            className={`py-1.5 px-2 rounded-xl text-[11px] font-medium transition ${
              updateChannel === 'beta'
                ? 'bg-purple-600 text-white font-bold shadow-[0_0_10px_rgba(168,85,247,0.5)]'
                : 'bg-slate-900 text-slate-400 hover:text-white border border-slate-800'
            }`}
          >
            Beta (বেটা)
          </button>
          <button
            onClick={() => { audioService.playCyberChime('beep'); setUpdateChannel('canary'); }}
            className={`py-1.5 px-2 rounded-xl text-[11px] font-medium transition ${
              updateChannel === 'canary'
                ? 'bg-cyan-500 text-black font-bold shadow-[0_0_10px_rgba(56,189,248,0.5)]'
                : 'bg-slate-900 text-slate-400 hover:text-white border border-slate-800'
            }`}
          >
            Canary / Nightly
          </button>
        </div>
      </div>

      {/* Auto-Update Preferences */}
      <div className="p-3.5 rounded-2xl bg-[#081525] border border-cyan-950 space-y-3">
        <span className="text-xs font-bold text-slate-300 tracking-wide uppercase block">
          স্বয়ংক্রিয় আপডেট সেটিংস (Auto-Update Settings)
        </span>

        {/* 1. Auto-check on launch */}
        <div className="flex items-center justify-between">
          <div className="space-y-0.5 pr-2">
            <h5 className="text-xs font-medium text-white">অ্যাপ চালু হলে স্বয়ংক্রিয় চেক করুন</h5>
            <p className="text-[10px] text-slate-400">প্রতিবার নতুন সংস্করণ আছে কিনা তা নিরূপণ করবে</p>
          </div>
          <button
            onClick={() => {
              audioService.playCyberChime('beep');
              setAutoCheckOnLaunch(!autoCheckOnLaunch);
            }}
            className={`w-11 h-6 rounded-full transition-colors relative shrink-0 p-0.5 ${
              autoCheckOnLaunch ? 'bg-cyan-500' : 'bg-slate-800'
            }`}
          >
            <div className={`w-5 h-5 rounded-full bg-white transition-transform ${
              autoCheckOnLaunch ? 'translate-x-5' : 'translate-x-0'
            }`}></div>
          </button>
        </div>

        {/* 2. Download over Wi-Fi only */}
        <div className="flex items-center justify-between pt-2 border-t border-slate-900">
          <div className="space-y-0.5 pr-2">
            <h5 className="text-xs font-medium text-white">কেবল Wi-Fi সংযোগে ডাউনলোড</h5>
            <p className="text-[10px] text-slate-400">মোবাইল ডাটা সাশ্রয় করতে সাহায্য করে</p>
          </div>
          <button
            onClick={() => {
              audioService.playCyberChime('beep');
              setWifiOnly(!wifiOnly);
            }}
            className={`w-11 h-6 rounded-full transition-colors relative shrink-0 p-0.5 ${
              wifiOnly ? 'bg-cyan-500' : 'bg-slate-800'
            }`}
          >
            <div className={`w-5 h-5 rounded-full bg-white transition-transform ${
              wifiOnly ? 'translate-x-5' : 'translate-x-0'
            }`}></div>
          </button>
        </div>

        {/* 3. Notify when APK ready */}
        <div className="flex items-center justify-between pt-2 border-t border-slate-900">
          <div className="space-y-0.5 pr-2">
            <h5 className="text-xs font-medium text-white">নতুন Android 16 APK পুশ নোটিফিকেশন</h5>
            <p className="text-[10px] text-slate-400">নতুন বাইনারি কম্পাইল হলে নোটিফাই করবে</p>
          </div>
          <button
            onClick={() => {
              audioService.playCyberChime('beep');
              setNotifyOnNewBuild(!notifyOnNewBuild);
            }}
            className={`w-11 h-6 rounded-full transition-colors relative shrink-0 p-0.5 ${
              notifyOnNewBuild ? 'bg-cyan-500' : 'bg-slate-800'
            }`}
          >
            <div className={`w-5 h-5 rounded-full bg-white transition-transform ${
              notifyOnNewBuild ? 'translate-x-5' : 'translate-x-0'
            }`}></div>
          </button>
        </div>
      </div>

      {/* Direct APK Link */}
      <div 
        onClick={onOpenApkModal}
        className="p-3.5 rounded-2xl bg-gradient-to-r from-emerald-950/40 via-cyan-950/40 to-blue-950/40 border border-emerald-500/30 flex items-center justify-between cursor-pointer hover:border-emerald-400 transition active:scale-95"
      >
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-emerald-500/15 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
            <Smartphone className="w-5 h-5" />
          </div>
          <div>
            <h4 className="text-xs font-bold text-white flex items-center gap-1.5">
              Android 16 APK প্যাকেজ ম্যানেজার
              <span className="text-[9px] px-1.5 py-0.2 rounded-full bg-emerald-950 text-emerald-300 border border-emerald-500/40 font-mono">
                APK_READY
              </span>
            </h4>
            <p className="text-[10px] text-slate-400">
              ফোনে সরাসরি ইনস্টল করতে মূল APK ডাউনলোড বা বিল্ড প্যানেল খুলুন
            </p>
          </div>
        </div>
        <ChevronRight className="w-4 h-4 text-slate-400 shrink-0" />
      </div>
    </div>
  );
};
