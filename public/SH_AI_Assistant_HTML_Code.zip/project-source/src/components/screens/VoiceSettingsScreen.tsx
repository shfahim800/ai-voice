import React, { useState } from 'react';
import { 
  ArrowLeft, 
  Mic, 
  Volume2, 
  Globe, 
  Check, 
  Play, 
  Sliders, 
  Sparkles, 
  Radio, 
  ShieldCheck, 
  Cpu, 
  Search,
  CheckCircle2,
  VolumeX,
  Languages
} from 'lucide-react';
import { VoiceConfig, VoiceLanguageOption } from '../../types/assistant';
import { audioService } from '../../services/audioService';

export const SUPPORTED_VOICE_LANGUAGES: VoiceLanguageOption[] = [
  {
    code: 'bn-BD',
    shortCode: 'bn',
    name: 'Bangla (Bangladesh)',
    nativeName: 'বাংলা (বাংলাদেশ)',
    flag: '🇧🇩',
    region: 'South Asia',
    sampleGreeting: 'হ্যালো! আমি এসএইচ এআই অ্যাসিস্ট্যান্ট। আমি কীভাবে আপনাকে সাহায্য করতে পারি?',
    accents: [
      { code: 'bn-BD', label: 'Dhaka Standard (প্রমিত বাংলা)' },
      { code: 'bn-BD-ctg', label: 'Chattogram' },
      { code: 'bn-BD-syl', label: 'Sylhet' }
    ]
  },
  {
    code: 'bn-IN',
    shortCode: 'bn',
    name: 'Bangla (India / Kolkata)',
    nativeName: 'বাংলা (ভারত / কলকাতা)',
    flag: '🇮🇳',
    region: 'South Asia',
    sampleGreeting: 'নমস্কার! এসএইচ এআই আপনার সেবায় সর্বদা প্রস্তুত।',
    accents: [
      { code: 'bn-IN', label: 'Kolkata Standard' }
    ]
  },
  {
    code: 'en-US',
    shortCode: 'en',
    name: 'English (United States)',
    nativeName: 'English (US)',
    flag: '🇺🇸',
    region: 'Global',
    sampleGreeting: 'Hello! I am SH AI Assistant. How can I help you today?',
    accents: [
      { code: 'en-US', label: 'Standard American' },
      { code: 'en-US-neural', label: 'Neural AI Fast' }
    ]
  },
  {
    code: 'en-GB',
    shortCode: 'en',
    name: 'English (United Kingdom)',
    nativeName: 'English (UK)',
    flag: '🇬🇧',
    region: 'Global',
    sampleGreeting: 'Greetings! SH AI Assistant ready to assist you.',
    accents: [
      { code: 'en-GB', label: 'British RP' }
    ]
  },
  {
    code: 'hi-IN',
    shortCode: 'hi',
    name: 'Hindi (India)',
    nativeName: 'हिन्दी (भारत)',
    flag: '🇮🇳',
    region: 'South Asia',
    sampleGreeting: 'नमस्ते! मैं SH AI असिस्टेंट हूँ। मैं आपकी क्या सहायता कर सकता हूँ?',
    accents: [
      { code: 'hi-IN', label: 'Delhi Standard Hindi' }
    ]
  },
  {
    code: 'ar-SA',
    shortCode: 'ar',
    name: 'Arabic (Saudi Arabia)',
    nativeName: 'العربية (السعودية)',
    flag: '🇸🇦',
    region: 'Middle East',
    sampleGreeting: 'مرحباً بك! أنا مساعد SH الذكي، كيف أستطيع مساعدتك اليوم؟',
    accents: [
      { code: 'ar-SA', label: 'Modern Standard Arabic' }
    ]
  },
  {
    code: 'ur-PK',
    shortCode: 'ur',
    name: 'Urdu (Pakistan)',
    nativeName: 'اردو (پاکستان)',
    flag: '🇵🇰',
    region: 'South Asia',
    sampleGreeting: 'السلام علیکم! میں آپ کا SH AI معاون ہوں۔ کیا خدمت کر سکتا ہوں؟',
    accents: [
      { code: 'ur-PK', label: 'Standard Urdu' }
    ]
  },
  {
    code: 'es-ES',
    shortCode: 'es',
    name: 'Spanish (Spain)',
    nativeName: 'Español (España)',
    flag: '🇪🇸',
    region: 'Global',
    sampleGreeting: '¡Hola! Soy SH AI Assistant. ¿En qué puedo ayudarte hoy?',
    accents: [
      { code: 'es-ES', label: 'Castilian' },
      { code: 'es-MX', label: 'Latin America' }
    ]
  },
  {
    code: 'fr-FR',
    shortCode: 'fr',
    name: 'French (France)',
    nativeName: 'Français (France)',
    flag: '🇫🇷',
    region: 'Global',
    sampleGreeting: 'Bonjour! Je suis votre assistant SH AI. Que puis-je faire pour vous?',
    accents: [
      { code: 'fr-FR', label: 'Standard Paris' }
    ]
  },
  {
    code: 'de-DE',
    shortCode: 'de',
    name: 'German (Germany)',
    nativeName: 'Deutsch (Deutschland)',
    flag: '🇩🇪',
    region: 'Global',
    sampleGreeting: 'Hallo! Ich bin dein SH AI Assistent. Wie kann ich dir helfen?',
    accents: [
      { code: 'de-DE', label: 'Hochdeutsch' }
    ]
  },
  {
    code: 'ja-JP',
    shortCode: 'ja',
    name: 'Japanese (Japan)',
    nativeName: '日本語 (日本)',
    flag: '🇯🇵',
    region: 'Asia Pacific',
    sampleGreeting: 'こんにちは！SH AIアシスタントです。何かご用でしょうか？',
    accents: [
      { code: 'ja-JP', label: 'Tokyo Standard' }
    ]
  },
  {
    code: 'zh-CN',
    shortCode: 'zh',
    name: 'Chinese (Mandarin)',
    nativeName: '中文 (普通话)',
    flag: '🇨🇳',
    region: 'Asia Pacific',
    sampleGreeting: '您好！我是 SH AI 智能语音助手，很高兴为您服务。',
    accents: [
      { code: 'zh-CN', label: 'Beijing Standard' }
    ]
  },
  {
    code: 'tr-TR',
    shortCode: 'tr',
    name: 'Turkish (Turkey)',
    nativeName: 'Türkçe (Türkiye)',
    flag: '🇹🇷',
    region: 'Middle East',
    sampleGreeting: 'Merhaba! Ben SH AI Asistanı. Size nasıl yardımcı olabilirim?',
    accents: [
      { code: 'tr-TR', label: 'Istanbul Standard' }
    ]
  },
  {
    code: 'ko-KR',
    shortCode: 'ko',
    name: 'Korean (South Korea)',
    nativeName: '한국어 (대한민국)',
    flag: '🇰🇷',
    region: 'Asia Pacific',
    sampleGreeting: '안녕하세요! SH AI 음성 비서입니다. 무엇을 도와드릴까요?',
    accents: [
      { code: 'ko-KR', label: 'Seoul Standard' }
    ]
  }
];

interface VoiceSettingsScreenProps {
  onBack: () => void;
  voiceConfig?: VoiceConfig;
  onUpdateConfig?: (config: VoiceConfig) => void;
}

export const VoiceSettingsScreen: React.FC<VoiceSettingsScreenProps> = ({
  onBack,
  voiceConfig,
  onUpdateConfig
}) => {
  const [config, setConfig] = useState<VoiceConfig>(
    voiceConfig || audioService.getConfig()
  );
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedRegion, setSelectedRegion] = useState<string>('all');
  const [isPlayingSample, setIsPlayingSample] = useState<string | null>(null);
  const [saveBanner, setSaveBanner] = useState(false);

  const currentLangObj = SUPPORTED_VOICE_LANGUAGES.find(
    l => l.code === config.selectedLanguage
  ) || SUPPORTED_VOICE_LANGUAGES[0];

  const handleSelectLanguage = (lang: VoiceLanguageOption) => {
    audioService.playCyberChime('beep');
    const updated = { ...config, selectedLanguage: lang.code };
    setConfig(updated);
    audioService.updateConfig(updated);
    if (onUpdateConfig) onUpdateConfig(updated);

    // Play greeting sample automatically
    playSample(lang);
    triggerSaveFeedback();
  };

  const handleToggleAutoDetect = () => {
    audioService.playCyberChime('beep');
    const updated = { ...config, autoDetectLanguage: !config.autoDetectLanguage };
    setConfig(updated);
    audioService.updateConfig(updated);
    if (onUpdateConfig) onUpdateConfig(updated);
    triggerSaveFeedback();
  };

  const handleRateChange = (rate: number) => {
    const updated = { ...config, speechRate: rate };
    setConfig(updated);
    audioService.updateConfig(updated);
    if (onUpdateConfig) onUpdateConfig(updated);
  };

  const handlePitchChange = (pitch: number) => {
    const updated = { ...config, speechPitch: pitch };
    setConfig(updated);
    audioService.updateConfig(updated);
    if (onUpdateConfig) onUpdateConfig(updated);
  };

  const handleGenderChange = (gender: 'female' | 'male' | 'neural') => {
    audioService.playCyberChime('beep');
    const updated = { ...config, voiceGender: gender };
    setConfig(updated);
    audioService.updateConfig(updated);
    if (onUpdateConfig) onUpdateConfig(updated);
    triggerSaveFeedback();
  };

  const handleWakeWordToggle = () => {
    audioService.playCyberChime('beep');
    const updated = { ...config, wakeWordEnabled: !config.wakeWordEnabled };
    setConfig(updated);
    audioService.updateConfig(updated);
    if (onUpdateConfig) onUpdateConfig(updated);
    triggerSaveFeedback();
  };

  const handleWakeWordPhraseChange = (phrase: string) => {
    const updated = { ...config, wakeWordPhrase: phrase };
    setConfig(updated);
    audioService.updateConfig(updated);
    if (onUpdateConfig) onUpdateConfig(updated);
    triggerSaveFeedback();
  };

  const playSample = (lang: VoiceLanguageOption) => {
    setIsPlayingSample(lang.code);
    audioService.speakSample(lang.sampleGreeting, lang.code, config.speechRate, config.speechPitch);
    setTimeout(() => {
      setIsPlayingSample(null);
    }, 4500);
  };

  const triggerSaveFeedback = () => {
    setSaveBanner(true);
    setTimeout(() => setSaveBanner(false), 2400);
  };

  // Filter languages
  const filteredLanguages = SUPPORTED_VOICE_LANGUAGES.filter(lang => {
    const matchesSearch = 
      lang.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      lang.nativeName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      lang.code.toLowerCase().includes(searchQuery.toLowerCase());
    
    if (selectedRegion === 'all') return matchesSearch;
    if (selectedRegion === 'south-asia') return matchesSearch && lang.region === 'South Asia';
    if (selectedRegion === 'global') return matchesSearch && lang.region === 'Global';
    if (selectedRegion === 'asia') return matchesSearch && (lang.region === 'Asia Pacific' || lang.region === 'Middle East');
    return matchesSearch;
  });

  return (
    <div className="w-full h-full flex flex-col justify-between bg-[#030712] select-none p-4 pb-20 overflow-y-auto space-y-4">
      {/* Top Header */}
      <div className="flex items-center justify-between pt-1">
        <button
          onClick={onBack}
          className="w-9 h-9 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-center text-slate-300 hover:text-cyan-400 active:scale-95 transition cursor-pointer"
        >
          <ArrowLeft className="w-4 h-4" />
        </button>

        <div className="text-center">
          <h2 className="text-sm font-bold text-white tracking-wide flex items-center justify-center gap-1.5">
            <Languages className="w-4 h-4 text-cyan-400" />
            Voice Settings
          </h2>
          <p className="text-[10px] text-cyan-400 font-medium">Multi-Language & Speech Engine</p>
        </div>

        <button
          onClick={() => playSample(currentLangObj)}
          className="w-9 h-9 rounded-xl bg-cyan-500/20 border border-cyan-500/40 flex items-center justify-center text-cyan-300 hover:scale-105 active:scale-95 transition"
          title="Test Voice"
        >
          <Play className="w-4 h-4 fill-cyan-400" />
        </button>
      </div>

      {/* Save Toast Feedback */}
      {saveBanner && (
        <div className="flex items-center justify-between p-2.5 rounded-xl bg-emerald-950/90 border border-emerald-500/40 text-emerald-300 text-xs animate-fade-in shadow-md">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
            <span>Voice Language Updated to <strong>{currentLangObj.nativeName}</strong></span>
          </div>
          <span className="text-[10px] bg-emerald-900/60 px-2 py-0.5 rounded-md font-mono">{config.selectedLanguage}</span>
        </div>
      )}

      {/* Active Language Highlight Card */}
      <div className="rounded-2xl bg-gradient-to-r from-[#0c223c] via-[#091b30] to-[#04101e] border border-cyan-500/40 p-4 shadow-[0_0_20px_rgba(56,189,248,0.2)] relative overflow-hidden">
        <div className="absolute top-0 right-0 w-32 h-32 bg-cyan-500/10 rounded-full blur-2xl pointer-events-none"></div>

        <div className="flex items-start justify-between">
          <div className="flex items-center gap-3">
            <span className="text-3xl filter drop-shadow-md">{currentLangObj.flag}</span>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-sm font-bold text-white">{currentLangObj.nativeName}</h3>
                <span className="text-[10px] bg-cyan-950 border border-cyan-500/40 text-cyan-300 px-2 py-0.5 rounded-full font-mono">
                  {currentLangObj.code}
                </span>
              </div>
              <p className="text-[11px] text-slate-400">{currentLangObj.name} • {currentLangObj.region}</p>
            </div>
          </div>

          <button
            onClick={() => playSample(currentLangObj)}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-cyan-500 text-slate-950 font-bold text-xs shadow-[0_0_12px_rgba(56,189,248,0.4)] hover:brightness-110 active:scale-95 transition cursor-pointer"
          >
            {isPlayingSample === currentLangObj.code ? (
              <>
                <Volume2 className="w-3.5 h-3.5 animate-pulse" />
                <span>বলছে...</span>
              </>
            ) : (
              <>
                <Play className="w-3.5 h-3.5 fill-slate-950" />
                <span>Test Voice</span>
              </>
            )}
          </button>
        </div>

        {/* Current Greeting Preview */}
        <div className="mt-3 p-2.5 rounded-xl bg-[#030a14]/80 border border-cyan-900/40">
          <p className="text-xs text-cyan-200/90 italic font-sans leading-relaxed">
            "{currentLangObj.sampleGreeting}"
          </p>
        </div>
      </div>

      {/* Auto-Detect Bilingual / Multilingual Mode Switch */}
      <div 
        onClick={handleToggleAutoDetect}
        className="flex items-center justify-between p-3.5 rounded-2xl bg-[#081525] border border-cyan-900/60 hover:border-cyan-500/40 transition cursor-pointer active:scale-[0.99]"
      >
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-indigo-500/15 border border-indigo-500/30 flex items-center justify-center text-indigo-400">
            <Globe className="w-5 h-5 stroke-[2]" />
          </div>
          <div>
            <h4 className="text-xs font-bold text-white flex items-center gap-1.5">
              <span>Auto-Detect Language</span>
              <span className="text-[9px] bg-indigo-950 border border-indigo-500/30 text-indigo-300 px-1.5 py-0.2 rounded-sm">
                দ্বিভাষিক
              </span>
            </h4>
            <p className="text-[10px] text-slate-400">
              Bangla, English বা যেকোনো ভাষায় বললে স্বয়ংক্রিয় বুঝবে
            </p>
          </div>
        </div>

        <div className={`w-11 h-6 flex items-center rounded-full p-1 transition duration-200 ${
          config.autoDetectLanguage ? 'bg-cyan-500 justify-end' : 'bg-slate-800 justify-start'
        }`}>
          <div className="w-4 h-4 rounded-full bg-slate-950 shadow-md"></div>
        </div>
      </div>

      {/* Voice Persona & Gender Selection */}
      <div className="rounded-2xl bg-[#081525] border border-cyan-950 p-3.5 space-y-3">
        <div className="flex items-center justify-between">
          <span className="text-xs font-bold text-white flex items-center gap-1.5">
            <Radio className="w-3.5 h-3.5 text-cyan-400" />
            Voice Persona & Gender (কণ্ঠস্বর)
          </span>
          <span className="text-[10px] text-slate-400 font-mono">Web Speech & Neural</span>
        </div>

        <div className="grid grid-cols-3 gap-2">
          {[
            { id: 'female', label: 'Female', sub: 'সুরেলা নারী', icon: '👩' },
            { id: 'male', label: 'Male', sub: 'পুরুষ কণ্ঠ', icon: '👨' },
            { id: 'neural', label: 'Neural AI', sub: 'রোবোটিক', icon: '🤖' },
          ].map((v) => {
            const isSelected = config.voiceGender === v.id;
            return (
              <button
                key={v.id}
                onClick={() => handleGenderChange(v.id as any)}
                className={`p-2.5 rounded-xl border flex flex-col items-center justify-center text-center transition cursor-pointer ${
                  isSelected 
                    ? 'bg-cyan-500/20 border-cyan-400 text-white shadow-[0_0_12px_rgba(56,189,248,0.3)]' 
                    : 'bg-[#050e1a] border-slate-800 text-slate-400 hover:text-white hover:border-slate-700'
                }`}
              >
                <span className="text-lg mb-1">{v.icon}</span>
                <span className="text-xs font-bold">{v.label}</span>
                <span className="text-[9px] text-slate-400">{v.sub}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Pitch & Speed Sliders */}
      <div className="rounded-2xl bg-[#081525] border border-cyan-950 p-3.5 space-y-3">
        <span className="text-xs font-bold text-white flex items-center gap-1.5">
          <Sliders className="w-3.5 h-3.5 text-cyan-400" />
          Speech Rate & Pitch Tuning
        </span>

        {/* Speed Slider */}
        <div className="space-y-1.5">
          <div className="flex justify-between text-[11px]">
            <span className="text-slate-400">Speed (কথা বলার গতি)</span>
            <span className="text-cyan-300 font-mono font-bold">{config.speechRate}x</span>
          </div>
          <input
            type="range"
            min="0.7"
            max="1.5"
            step="0.05"
            value={config.speechRate}
            onChange={(e) => handleRateChange(parseFloat(e.target.value))}
            className="w-full accent-cyan-400 bg-slate-800 h-1.5 rounded-lg cursor-pointer"
          />
        </div>

        {/* Pitch Slider */}
        <div className="space-y-1.5 pt-1">
          <div className="flex justify-between text-[11px]">
            <span className="text-slate-400">Pitch (কণ্ঠের সুর)</span>
            <span className="text-cyan-300 font-mono font-bold">{config.speechPitch}x</span>
          </div>
          <input
            type="range"
            min="0.8"
            max="1.3"
            step="0.05"
            value={config.speechPitch}
            onChange={(e) => handlePitchChange(parseFloat(e.target.value))}
            className="w-full accent-cyan-400 bg-slate-800 h-1.5 rounded-lg cursor-pointer"
          />
        </div>
      </div>

      {/* Wake Word Configuration */}
      <div className="rounded-2xl bg-[#081525] border border-cyan-950 p-3.5 space-y-3">
        <div className="flex items-center justify-between">
          <div>
            <h4 className="text-xs font-bold text-white flex items-center gap-1.5">
              <Mic className="w-3.5 h-3.5 text-cyan-400" />
              Wake Word Detection
            </h4>
            <p className="text-[10px] text-slate-400">ভয়েস কমান্ড দিয়ে অ্যাপ সক্রিয় করুন</p>
          </div>

          <div 
            onClick={handleWakeWordToggle}
            className={`w-11 h-6 flex items-center rounded-full p-1 transition duration-200 cursor-pointer ${
              config.wakeWordEnabled ? 'bg-cyan-500 justify-end' : 'bg-slate-800 justify-start'
            }`}
          >
            <div className="w-4 h-4 rounded-full bg-slate-950 shadow-md"></div>
          </div>
        </div>

        {config.wakeWordEnabled && (
          <div className="space-y-2 pt-1">
            <span className="text-[10px] text-slate-400">পছন্দের ওয়েক-ওয়ার্ড বেছে নিন:</span>
            <div className="flex flex-wrap gap-2">
              {[
                'হেই এসএইচ',
                'Hey SH',
                'শোনো এসএইচ',
                'Ok Assistant',
                'नमस्ते एसएच'
              ].map((phrase) => (
                <button
                  key={phrase}
                  onClick={() => handleWakeWordPhraseChange(phrase)}
                  className={`text-xs px-3 py-1.5 rounded-xl border transition cursor-pointer ${
                    config.wakeWordPhrase === phrase
                      ? 'bg-cyan-500 text-slate-950 font-bold border-cyan-400'
                      : 'bg-[#050e1a] border-slate-800 text-slate-300 hover:border-slate-700'
                  }`}
                >
                  "{phrase}"
                </button>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Available Languages Directory Header */}
      <div className="space-y-2.5 pt-1">
        <div className="flex items-center justify-between">
          <h3 className="text-xs font-bold text-white flex items-center gap-1.5">
            <Globe className="w-3.5 h-3.5 text-cyan-400" />
            Select Voice Language ({SUPPORTED_VOICE_LANGUAGES.length} Languages)
          </h3>
          <span className="text-[10px] text-cyan-400 font-mono">STT + TTS</span>
        </div>

        {/* Search Input */}
        <div className="relative">
          <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search language (e.g. বাংলা, English, Hindi, Arabic)..."
            className="w-full bg-[#081525] border border-cyan-950 rounded-xl pl-9 pr-3 py-2 text-xs text-white placeholder:text-slate-500 focus:outline-hidden focus:border-cyan-500/60"
          />
        </div>

        {/* Region Filter Tabs */}
        <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar py-1">
          {[
            { id: 'all', label: 'All Languages' },
            { id: 'south-asia', label: '🇧🇩 বাংলা & South Asia' },
            { id: 'global', label: '🌐 Global (EN/ES/FR/DE)' },
            { id: 'asia', label: '🇯🇵 Middle East & East Asia' }
          ].map(tab => (
            <button
              key={tab.id}
              onClick={() => setSelectedRegion(tab.id)}
              className={`text-[10px] px-2.5 py-1 rounded-full whitespace-nowrap transition cursor-pointer ${
                selectedRegion === tab.id
                  ? 'bg-cyan-500 text-slate-950 font-bold'
                  : 'bg-[#081525] text-slate-400 border border-slate-800 hover:text-white'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* Language List */}
        <div className="space-y-2 max-h-80 overflow-y-auto pr-0.5">
          {filteredLanguages.map((lang) => {
            const isSelected = config.selectedLanguage === lang.code;
            const isPlayingThis = isPlayingSample === lang.code;

            return (
              <div
                key={lang.code}
                className={`flex items-center justify-between p-3 rounded-2xl border transition duration-150 cursor-pointer ${
                  isSelected 
                    ? 'bg-[#0b2440] border-cyan-400 shadow-[0_0_15px_rgba(56,189,248,0.25)]' 
                    : 'bg-[#081525] border-cyan-950 hover:border-cyan-500/40'
                }`}
                onClick={() => handleSelectLanguage(lang)}
              >
                <div className="flex items-center gap-3">
                  <span className="text-2xl">{lang.flag}</span>
                  <div>
                    <div className="flex items-center gap-2">
                      <h4 className={`text-xs font-bold ${isSelected ? 'text-white' : 'text-slate-200'}`}>
                        {lang.nativeName}
                      </h4>
                      {isSelected && (
                        <span className="text-[9px] bg-cyan-400 text-slate-950 px-1.5 py-0.2 rounded font-bold">
                          Active
                        </span>
                      )}
                    </div>
                    <p className="text-[10px] text-slate-400">
                      {lang.name} • <span className="font-mono text-cyan-400/80">{lang.code}</span>
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2" onClick={(e) => e.stopPropagation()}>
                  <button
                    onClick={() => playSample(lang)}
                    className={`w-8 h-8 rounded-xl flex items-center justify-center transition cursor-pointer ${
                      isPlayingThis 
                        ? 'bg-rose-500 text-white animate-pulse' 
                        : 'bg-[#040e1b] border border-cyan-900 text-slate-300 hover:text-cyan-300 hover:border-cyan-400'
                    }`}
                    title="Play voice preview"
                  >
                    {isPlayingThis ? (
                      <Volume2 className="w-3.5 h-3.5" />
                    ) : (
                      <Play className="w-3.5 h-3.5 fill-current" />
                    )}
                  </button>

                  <div 
                    onClick={() => handleSelectLanguage(lang)}
                    className={`w-6 h-6 rounded-full flex items-center justify-center ${
                      isSelected ? 'bg-cyan-400 text-slate-950' : 'border border-slate-700 text-transparent'
                    }`}
                  >
                    <Check className="w-3.5 h-3.5 stroke-[3]" />
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Done & Apply Button */}
      <div className="pt-2">
        <button
          onClick={() => {
            audioService.playCyberChime('success');
            onBack();
          }}
          className="w-full py-3 rounded-2xl bg-gradient-to-r from-cyan-500 to-blue-600 text-slate-950 font-bold text-xs shadow-[0_0_20px_rgba(56,189,248,0.4)] hover:brightness-110 active:scale-95 transition flex items-center justify-center gap-2 cursor-pointer"
        >
          <CheckCircle2 className="w-4 h-4 text-slate-950" />
          <span>Save Voice Settings (সেভ করুন)</span>
        </button>
      </div>
    </div>
  );
};
