import React, { useState } from 'react';
import { 
  Mic, 
  Palette, 
  ShieldCheck, 
  Bell, 
  Wifi, 
  Info, 
  ChevronRight,
  Sparkles,
  Heart,
  CheckCircle2,
  X,
  FileCode,
  DownloadCloud
} from 'lucide-react';
import { ScreenType } from '../../types/assistant';
import { audioService } from '../../services/audioService';
import { downloadHtmlCodeZip } from '../../services/apkGenerator';

import { themeService } from '../../services/themeService';

interface SettingsScreenProps {
  onNavigate: (screen: ScreenType) => void;
  onOpenApkModal: () => void;
}

export const SettingsScreen: React.FC<SettingsScreenProps> = ({
  onNavigate,
  onOpenApkModal
}) => {
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const currentVoiceConfig = audioService.getConfig();
  const currentThemeConfig = themeService.getConfig();

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3000);
  };

  const settingsOptions = [
    {
      id: 'voice',
      name: 'Voice Settings',
      desc: `Multi-Language (${currentVoiceConfig.selectedLanguage}) • Wake Word • Neural Voice`,
      icon: Mic,
      color: 'text-cyan-400 bg-cyan-500/15 border-cyan-500/30',
      action: () => onNavigate('voice-settings')
    },
    {
      id: 'appearance',
      name: 'Appearance & Themes',
      desc: `${currentThemeConfig.name} • Cyberpunk, iOS Liquid Glass, OLED`,
      icon: Palette,
      color: 'text-indigo-400 bg-indigo-500/15 border-indigo-500/30',
      action: () => onNavigate('appearance')
    },
    {
      id: 'security-permissions',
      name: 'Security & Permissions (উন্নত পারমিশন)',
      desc: 'মিলিটারি এনক্রিপশন, সিকিউরিটি অডিট, গ্র্যানুলার পারমিশন ও পিন',
      icon: ShieldCheck,
      color: 'text-emerald-400 bg-emerald-500/15 border-emerald-500/30',
      action: () => onNavigate('security-permissions')
    },
    {
      id: 'software-update',
      name: 'Software & App Update (অ্যাপ আপডেট)',
      desc: 'v2.5.0 Available • OTA প্যাকেজ ডাউনলোড ও আপডেট চেক',
      icon: DownloadCloud,
      color: 'text-cyan-400 bg-cyan-500/15 border-cyan-500/30',
      action: () => onNavigate('software-update')
    },
    {
      id: 'notifications',
      name: 'Notifications',
      desc: 'Wake Word alerts, Assistant reminders',
      icon: Bell,
      color: 'text-amber-400 bg-amber-500/15 border-amber-500/30',
      action: () => showToast('Notifications: Sound & haptic triggers enabled.')
    },
    {
      id: 'network',
      name: 'Network & PC Control',
      desc: 'Wi-Fi Socket, Windows Companion, Offline Mode',
      icon: Wifi,
      color: 'text-sky-400 bg-sky-500/15 border-sky-500/30',
      action: () => onNavigate('connected-devices')
    },
    {
      id: 'ai-models',
      name: 'AI Agent & APIs',
      desc: 'Gemini 2.5 Flash, Ollama, OpenAI GPT-4, Groq',
      icon: Sparkles,
      color: 'text-blue-400 bg-blue-500/15 border-blue-500/30',
      action: () => onNavigate('ai-settings')
    },
    {
      id: 'html-zip',
      name: 'HTML Code ZIP (ওয়েব সোর্স)',
      desc: 'Standalone HTML5 (Zero-install) + React 19 Project',
      icon: FileCode,
      color: 'text-cyan-400 bg-cyan-500/15 border-cyan-500/30',
      action: async () => {
        showToast('HTML Code ZIP ডাউনলোড শুরু হচ্ছে...');
        await downloadHtmlCodeZip();
      }
    },
    {
      id: 'apk-build',
      name: 'Android 16 APK Export',
      desc: 'SDK 36, Java 21, Gradle 8.13, Architecture',
      icon: ShieldCheck,
      color: 'text-emerald-400 bg-emerald-500/15 border-emerald-500/30',
      action: () => onOpenApkModal()
    },
    {
      id: 'about',
      name: 'About SH AI Assistant',
      desc: 'Version 1.0 (Build 36) • Android 16 Ready',
      icon: Info,
      color: 'text-purple-400 bg-purple-500/15 border-purple-500/30',
      action: () => showToast('SH AI Assistant v1.0. Engineered for next-gen Android 16.')
    }
  ];

  return (
    <div className="w-full h-full flex flex-col justify-between bg-[#030712] select-none p-4 pb-20 overflow-y-auto space-y-4">
      {/* Header matching Screen 9 */}
      <div className="flex items-center gap-2.5 pt-1">
        <div className="w-8 h-8 rounded-lg bg-cyan-500/15 border border-cyan-500/30 flex items-center justify-center text-cyan-400">
          <ShieldCheck className="w-4 h-4" />
        </div>
        <div>
          <h2 className="text-sm font-bold text-white tracking-wide">Settings</h2>
          <p className="text-[10px] text-slate-400">System Preferences & Voice Config</p>
        </div>
      </div>

      {/* In-app Toast Banner */}
      {toastMessage && (
        <div className="flex items-center justify-between p-3 rounded-xl bg-[#081f38] border border-cyan-500/40 text-cyan-200 text-xs shadow-lg animate-fade-in">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-cyan-400 shrink-0" />
            <span>{toastMessage}</span>
          </div>
          <button 
            onClick={() => setToastMessage(null)}
            className="text-slate-400 hover:text-white p-1"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* Settings list */}
      <div className="space-y-2">
        {settingsOptions.map((opt) => {
          const Icon = opt.icon;
          return (
            <div
              key={opt.id}
              onClick={() => {
                audioService.playCyberChime('beep');
                if (opt.action) {
                  opt.action();
                }
              }}
              className="flex items-center justify-between p-3.5 rounded-2xl bg-[#081525] border border-cyan-950 hover:border-cyan-500/40 transition duration-150 cursor-pointer shadow-sm group active:scale-[0.99]"
            >
              <div className="flex items-center gap-3.5">
                <div className={`w-10 h-10 rounded-xl border flex items-center justify-center ${opt.color} group-hover:scale-105 transition`}>
                  <Icon className="w-5 h-5 stroke-[2]" />
                </div>
                <div>
                  <h4 className="text-xs font-bold text-white group-hover:text-cyan-300 transition flex items-center gap-1.5">
                    {opt.name}
                    {opt.id === 'voice' && (
                      <span className="text-[9px] bg-cyan-950 border border-cyan-500/40 text-cyan-300 px-1.5 py-0.2 rounded-full">
                        Multi-Lang
                      </span>
                    )}
                  </h4>
                  <p className="text-[10px] text-slate-400">
                    {opt.desc}
                  </p>
                </div>
              </div>

              <ChevronRight className="w-4 h-4 text-slate-500 group-hover:text-cyan-400 transition" />
            </div>
          );
        })}
      </div>

      {/* Footer Branding Card from Mockup */}
      <div className="rounded-2xl bg-gradient-to-r from-[#07172b] to-[#0a1f3a] border border-cyan-500/30 p-4 flex items-center gap-3.5 shadow-sm mt-4">
        <div className="w-12 h-12 rounded-full bg-cyan-500/20 border border-cyan-400/50 flex items-center justify-center shadow-[0_0_12px_rgba(56,189,248,0.3)] shrink-0">
          <span className="text-base font-black text-cyan-300">SH</span>
        </div>
        <div className="flex-1 min-w-0">
          <h4 className="text-xs font-bold text-white flex items-center gap-1.5">
            SH AI Assistant v1.0
          </h4>
          <p className="text-[10px] text-slate-400 flex items-center gap-1 mt-0.5">
            Built with <Heart className="w-3 h-3 text-rose-500 fill-rose-500" /> for a better you
          </p>
        </div>
      </div>
    </div>
  );
};
