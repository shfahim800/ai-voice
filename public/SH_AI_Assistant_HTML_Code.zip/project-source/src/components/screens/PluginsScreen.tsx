import React, { useState } from 'react';
import { 
  Bot, 
  Mic, 
  Volume2, 
  Search, 
  Folder, 
  Grid, 
  Languages, 
  Calculator, 
  Activity, 
  Workflow,
  Sparkles,
  Check
} from 'lucide-react';
import { PluginItem } from '../../types/assistant';
import { audioService } from '../../services/audioService';

interface PluginsScreenProps {
  plugins: PluginItem[];
  onTogglePlugin: (id: string) => void;
  onOpenPluginModal?: (pluginId: string) => void;
}

export const PluginsScreen: React.FC<PluginsScreenProps> = ({
  plugins,
  onTogglePlugin,
  onOpenPluginModal
}) => {
  const [filter, setFilter] = useState<'all' | 'active' | 'available'>('all');

  const filteredPlugins = plugins.filter((p) => {
    if (filter === 'active') return p.enabled;
    if (filter === 'available') return !p.enabled;
    return true;
  });

  const getPluginIcon = (name: string) => {
    switch (name) {
      case 'AI Chat': return Bot;
      case 'Voice Recognition': return Mic;
      case 'Text to Speech': return Volume2;
      case 'Web Search': return Search;
      case 'File Manager': return Folder;
      case 'App Launcher': return Grid;
      case 'Translation': return Languages;
      case 'Calculator': return Calculator;
      case 'System Monitor': return Activity;
      case 'Automation': return Workflow;
      default: return Sparkles;
    }
  };

  const handleToggle = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    audioService.playCyberChime('beep');
    onTogglePlugin(id);
  };

  return (
    <div className="w-full h-full flex flex-col justify-between bg-[#030712] select-none p-4 pb-20 overflow-y-auto space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between pt-1">
        <div className="flex items-center gap-2">
          <h2 className="text-base font-bold text-white tracking-wide">Plugins</h2>
          <span className="text-xs font-bold text-white bg-blue-600 px-2.5 py-0.5 rounded-full border border-cyan-400/50 shadow-sm">
            {plugins.filter(p => p.enabled).length}
          </span>
        </div>
        <span className="text-[11px] text-cyan-400 font-medium">10+ Smart Tools</span>
      </div>

      {/* Filter Tabs */}
      <div className="flex items-center gap-2 bg-[#091524] p-1 rounded-xl border border-cyan-950">
        <button
          onClick={() => { setFilter('all'); audioService.playCyberChime(); }}
          className={`flex-1 py-1.5 text-xs font-semibold rounded-lg transition ${
            filter === 'all' 
              ? 'bg-blue-600 text-white shadow-sm' 
              : 'text-slate-400 hover:text-white'
          }`}
        >
          All
        </button>
        <button
          onClick={() => { setFilter('active'); audioService.playCyberChime(); }}
          className={`flex-1 py-1.5 text-xs font-semibold rounded-lg transition ${
            filter === 'active' 
              ? 'bg-blue-600 text-white shadow-sm' 
              : 'text-slate-400 hover:text-white'
          }`}
        >
          Active
        </button>
        <button
          onClick={() => { setFilter('available'); audioService.playCyberChime(); }}
          className={`flex-1 py-1.5 text-xs font-semibold rounded-lg transition ${
            filter === 'available' 
              ? 'bg-blue-600 text-white shadow-sm' 
              : 'text-slate-400 hover:text-white'
          }`}
        >
          Available
        </button>
      </div>

      {/* Plugins List */}
      <div className="space-y-2.5">
        {filteredPlugins.map((plugin) => {
          const Icon = getPluginIcon(plugin.name);
          return (
            <div
              key={plugin.id}
              onClick={() => onOpenPluginModal && onOpenPluginModal(plugin.id)}
              className="flex items-center justify-between p-3.5 rounded-2xl bg-[#081525] border border-cyan-950 hover:border-cyan-500/40 transition duration-150 cursor-pointer shadow-sm group"
            >
              <div className="flex items-center gap-3.5">
                <div className={`w-10 h-10 rounded-xl flex items-center justify-center transition ${
                  plugin.enabled 
                    ? 'bg-cyan-500/15 border border-cyan-500/40 text-cyan-400 shadow-[0_0_10px_rgba(56,189,248,0.2)]'
                    : 'bg-slate-900 border border-slate-800 text-slate-500'
                }`}>
                  <Icon className="w-5 h-5 stroke-[2]" />
                </div>
                <div>
                  <h4 className="text-xs font-bold text-white group-hover:text-cyan-300 transition">
                    {plugin.name}
                  </h4>
                  <p className="text-[10px] text-slate-400">
                    {plugin.description}
                  </p>
                </div>
              </div>

              {/* iOS / Android style toggle switch */}
              <button
                type="button"
                onClick={(e) => handleToggle(plugin.id, e)}
                className={`w-11 h-6 flex items-center rounded-full p-0.5 transition-colors duration-200 cursor-pointer ${
                  plugin.enabled ? 'bg-cyan-500 shadow-[0_0_10px_rgba(56,189,248,0.5)]' : 'bg-slate-800'
                }`}
                title={plugin.enabled ? 'Enabled' : 'Disabled'}
              >
                <div
                  className={`bg-white w-5 h-5 rounded-full shadow-md transform transition-transform duration-200 flex items-center justify-center ${
                    plugin.enabled ? 'translate-x-5' : 'translate-x-0'
                  }`}
                >
                  {plugin.enabled && <Check className="w-3 h-3 text-cyan-600 stroke-[3]" />}
                </div>
              </button>
            </div>
          );
        })}
      </div>
    </div>
  );
};
