// Web Audio API & Speech Synthesis / Speech Recognition for SH AI Assistant
import { VoiceConfig } from '../types/assistant';

class AudioService {
  private audioCtx: AudioContext | null = null;
  private recognition: any = null;
  private isListening: boolean = false;
  private currentConfig: VoiceConfig = {
    selectedLanguage: 'bn-BD',
    autoDetectLanguage: true,
    speechRate: 1.0,
    speechPitch: 1.05,
    voiceGender: 'female',
    wakeWordEnabled: true,
    wakeWordPhrase: 'হেই এসএইচ',
    noiseSuppression: true,
    offlineVoiceModel: false
  };

  private initAudio() {
    if (!this.audioCtx && typeof window !== 'undefined') {
      const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
      if (AudioContextClass) {
        this.audioCtx = new AudioContextClass();
      }
    }
  }

  // Update voice configuration settings
  updateConfig(newConfig: Partial<VoiceConfig>) {
    this.currentConfig = { ...this.currentConfig, ...newConfig };
  }

  getConfig(): VoiceConfig {
    return this.currentConfig;
  }

  // Futuristic tech sound effect for button clicks and triggers
  playCyberChime(type: 'beep' | 'activate' | 'success' | 'alert' = 'beep') {
    try {
      this.initAudio();
      if (!this.audioCtx) return;

      const osc = this.audioCtx.createOscillator();
      const gain = this.audioCtx.createGain();
      osc.connect(gain);
      gain.connect(this.audioCtx.destination);

      const now = this.audioCtx.currentTime;

      if (type === 'activate') {
        osc.type = 'sine';
        osc.frequency.setValueAtTime(440, now);
        osc.frequency.exponentialRampToValueAtTime(880, now + 0.15);
        osc.frequency.exponentialRampToValueAtTime(1760, now + 0.3);
        gain.gain.setValueAtTime(0.08, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.35);
        osc.start(now);
        osc.stop(now + 0.35);
      } else if (type === 'success') {
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(587.33, now); // D5
        osc.frequency.setValueAtTime(880, now + 0.1); // A5
        gain.gain.setValueAtTime(0.09, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.25);
        osc.start(now);
        osc.stop(now + 0.25);
      } else if (type === 'alert') {
        osc.type = 'sawtooth';
        osc.frequency.setValueAtTime(300, now);
        osc.frequency.setValueAtTime(200, now + 0.1);
        gain.gain.setValueAtTime(0.1, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.25);
        osc.start(now);
        osc.stop(now + 0.25);
      } else {
        osc.type = 'sine';
        osc.frequency.setValueAtTime(800, now);
        gain.gain.setValueAtTime(0.06, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.08);
        osc.start(now);
        osc.stop(now + 0.08);
      }
    } catch (e) {
      // Audio policy catch
    }
  }

  // Multi-language text-to-speech
  speak(text: string, lang?: string, options?: { rate?: number; pitch?: number; gender?: string }) {
    if (typeof window === 'undefined' || !('speechSynthesis' in window)) {
      return;
    }
    window.speechSynthesis.cancel();

    const utterance = new SpeechSynthesisUtterance(text);
    utterance.rate = options?.rate ?? this.currentConfig.speechRate;
    utterance.pitch = options?.pitch ?? this.currentConfig.speechPitch;

    // Determine language: explicit > auto-detect > selected language
    let targetLang = lang || this.currentConfig.selectedLanguage;
    if (this.currentConfig.autoDetectLanguage) {
      if (/[\u0980-\u09FF]/.test(text)) {
        targetLang = 'bn-BD';
      } else if (/[\u0900-\u097F]/.test(text)) {
        targetLang = 'hi-IN';
      } else if (/[\u0600-\u06FF]/.test(text)) {
        targetLang = 'ar-SA';
      } else if (/[\u3040-\u30FF\u4E00-\u9FAF]/.test(text)) {
        targetLang = 'ja-JP';
      } else if (/[a-zA-Z]/.test(text) && targetLang.startsWith('bn')) {
        targetLang = 'en-US';
      }
    }
    utterance.lang = targetLang;

    const voices = window.speechSynthesis.getVoices();
    const primaryCode = targetLang.split('-')[0].toLowerCase();
    
    // Pick appropriate voice
    const matchedVoice = voices.find(v => {
      const vLang = v.lang.toLowerCase();
      return vLang === targetLang.toLowerCase() || vLang.startsWith(primaryCode);
    });

    if (matchedVoice) {
      utterance.voice = matchedVoice;
    }

    window.speechSynthesis.speak(utterance);
  }

  // Test sample speech in specified language
  speakSample(text: string, langCode: string, rate = 1.0, pitch = 1.0) {
    this.speak(text, langCode, { rate, pitch });
  }

  stopSpeaking() {
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      window.speechSynthesis.cancel();
    }
  }

  // Start Voice Recognition with configured or provided multi-language code
  startListening(
    onResult: (transcript: string) => void,
    onError: (error: string) => void,
    lang?: string
  ): boolean {
    if (typeof window === 'undefined') return false;

    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRecognition) {
      onError("Speech Recognition not supported in this browser. Try Chrome on Android or Desktop.");
      return false;
    }

    try {
      this.recognition = new SpeechRecognition();
      this.recognition.continuous = false;
      this.recognition.interimResults = true;
      this.recognition.lang = lang || this.currentConfig.selectedLanguage || 'bn-BD';

      this.recognition.onresult = (event: any) => {
        let currentTranscript = '';
        for (let i = event.resultIndex; i < event.results.length; i++) {
          currentTranscript += event.results[i][0].transcript;
        }
        onResult(currentTranscript);
      };

      this.recognition.onerror = (event: any) => {
        onError(event.error);
        this.isListening = false;
      };

      this.recognition.onend = () => {
        this.isListening = false;
      };

      this.recognition.start();
      this.isListening = true;
      this.playCyberChime('activate');
      return true;
    } catch (err: any) {
      onError(err.message || 'Error starting speech recognition');
      return false;
    }
  }

  stopListening() {
    if (this.recognition && this.isListening) {
      try {
        this.recognition.stop();
      } catch (e) {}
      this.isListening = false;
    }
  }
}

export const audioService = new AudioService();
